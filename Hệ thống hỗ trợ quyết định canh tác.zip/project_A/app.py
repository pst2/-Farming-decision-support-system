import streamlit as st
import numpy as np
import joblib
import base64

#model
clf = joblib.load("models/canh_tac_classifier.pkl")
scaler = joblib.load("models/scaler.pkl")

#cấu hình trang
st.set_page_config(
    page_title="Hệ thống hỗ trợ quyết định canh tác",
    layout="wide"
)

#background
def set_bg_from_local(image_path):
    with open(image_path, "rb") as img:
        encoded = base64.b64encode(img.read()).decode()

    st.markdown(
        f"""
        <style>
        .stApp {{
            background-image:
                linear-gradient(rgba(0,0,0,0.55), rgba(0,0,0,0.55)),
                url("data:image/png;base64,{encoded}");
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
        }}

        h1, h2, h3, p, label {{
            color: white !important;
        }}

        .stButton > button {{
            background-color: #1abc9c;
            color: black;
            font-size: 18px;
            font-weight: bold;
            border-radius: 10px;
            height: 3em;
        }}

        .stButton > button:hover {{
            background-color: #16a085;
            color: white;
        }}
        </style>
        """,
        unsafe_allow_html=True
    )

set_bg_from_local("assets/background.png")

#khuyến nghị canh tác
def recommend(luong_mua, nhiet_do, do_am, muc):
    rec = []

   #đánh giá trạng thái
    if muc == "Thap":
        rec.append("🔴 Hệ canh tác đang ở trạng thái rủi ro cao, cần ưu tiên ổn định hơn là mở rộng.")
        rec.append("🧭 Chiến lược phù hợp: giảm đầu vào – tăng khả năng chống chịu.")
    elif muc == "TrungBinh":
        rec.append("🟡 Hệ canh tác ở trạng thái trung gian, có thể sản xuất nhưng cần quản lý rủi ro.")
        rec.append("🧭 Chiến lược phù hợp: sản xuất thận trọng – giám sát chặt chẽ.")
    else:
        rec.append("🟢 Hệ canh tác ổn định, có thể khai thác tiềm năng sinh trưởng của cây trồng.")
        rec.append("🧭 Chiến lược phù hợp: tối ưu năng suất đi kèm bền vững.")

   #phân tích nước
    if luong_mua < 900:
        rec.append("💧 Thiếu nước nghiêm trọng – nguy cơ hạn sinh lý và giảm năng suất sớm.")
        rec.append("🔧 Ưu tiên tưới nhỏ giọt hoặc tưới theo nhu cầu sinh trưởng của cây.")
    elif 900 <= luong_mua < 1200:
        rec.append("💧 Nguồn nước hạn chế – cần tối ưu lịch tưới và che phủ đất.")
    elif 1200 <= luong_mua <= 1500:
        rec.append("💧 Nguồn nước tương đối phù hợp cho đa số hệ cây trồng cạn.")
    else:
        rec.append("🌧️ Nguy cơ úng và rửa trôi dinh dưỡng – cần kiểm soát dòng chảy bề mặt.")

    #nhiệt độ
    if nhiet_do > 38:
        rec.append("🔥 Stress nhiệt nghiêm trọng – quang hợp giảm, hô hấp tăng.")
        rec.append("🔧 Giải pháp: che lưới, tưới làm mát, giảm mật độ cây.")
    elif 35 < nhiet_do <= 38:
        rec.append("🔥 Stress nhiệt nhẹ – cần điều chỉnh chế độ phân bón (giảm đạm).")
    elif 25 <= nhiet_do <= 35:
        rec.append("🌡️ Nhiệt độ nằm trong ngưỡng sinh lý tối ưu của nhiều cây trồng.")
    else:
        rec.append("❄️ Nhiệt độ thấp – sinh trưởng chậm, cần kéo dài thời vụ hoặc chọn giống phù hợp.")

    #độ ẩm
    if do_am > 95:
        rec.append("🐛 Môi trường thuận lợi cho nấm bệnh và vi khuẩn gây hại.")
        rec.append("🧪 Ưu tiên biện pháp IPM: giống kháng, vi sinh, thông thoáng tán cây.")
    elif 85 <= do_am <= 95:
        rec.append("🐛 Nguy cơ sâu bệnh ở mức trung bình – cần giám sát sớm.")
    elif 70 <= do_am < 85:
        rec.append("🌱 Độ ẩm phù hợp, hệ sinh thái đất – rễ hoạt động ổn định.")
    else:
        rec.append("🌱 Độ ẩm thấp – tăng nguy cơ stress nước, cần giữ ẩm đất.")

    #đất
    if muc == "Thap":
        rec.append("🌾 Tập trung cải tạo đất: tăng hữu cơ, giảm phân hóa học.")
        rec.append("♻️ Ưu tiên hệ canh tác bền vững, giảm rủi ro vụ sau.")
    elif muc == "TrungBinh":
        rec.append("🌾 Bón phân cân đối, tránh thâm canh quá mức.")
    else:
        rec.append("🌾 Có thể thâm canh có kiểm soát, chú ý cân bằng N–P–K và vi lượng.")

    #forecast và khuyến nghị 
    rec.append("📅 Theo dõi dự báo thời tiết 7–10 ngày để điều chỉnh lịch canh tác.")
    rec.append("📈 Ghi chép dữ liệu sản xuất để đánh giá hiệu quả và cải tiến mô hình.")
    rec.append("🔍 Nếu điều kiện biến động mạnh, nên ưu tiên an toàn sinh thái hơn năng suất.")

    return rec


#subtitle
st.markdown(
    """
    <h1 style="text-align:center; font-size:42px; font-weight:700;">
        🌾 HỆ THỐNG HỖ TRỢ QUYẾT ĐỊNH CANH TÁC
    </h1>
    """,
    unsafe_allow_html=True
)

st.markdown(
    "<p style='text-align:center; font-size:18px;'>"
    "Dựa trên điều kiện thời tiết và mô hình Machine Learning"
    "</p>",
    unsafe_allow_html=True
)

st.markdown("---")

#input
col1, col2, col3 = st.columns([1, 2, 1])

with col2:
    st.subheader("📥 Nhập dữ liệu thời tiết")

    luong_mua = st.text_input("🌧️ Lượng mưa (mm)", "1400")
    nhiet_do = st.text_input("🌡️ Nhiệt độ (°C)", "32")
    do_am = st.text_input("💧 Độ ẩm (%)", "95")

    analyze = st.button("🚀 Phân tích & Khuyến nghị", use_container_width=True)

#forecast và khuyến nghị
if analyze:
    try:
        luong_mua = float(luong_mua)
        nhiet_do = float(nhiet_do)
        do_am = float(do_am)
    except ValueError:
        st.error("Vui lòng nhập số hợp lệ cho tất cả các trường dữ liệu!")
        st.stop()

    input_data = np.array([[luong_mua, nhiet_do, do_am]])
    input_scaled = scaler.transform(input_data)
    muc = clf.predict(input_scaled)[0]

    st.markdown("---")
    st.subheader("📊 KẾT QUẢ PHÂN TÍCH")

    if muc == "Thap":
        st.error("🔴 Mức canh tác: THẤP")
    elif muc == "TrungBinh":
        st.warning("🟡 Mức canh tác: TRUNG BÌNH")
    else:
        st.success("🟢 Mức canh tác: CAO")

    st.subheader("🌱 KHUYẾN NGHỊ CANH TÁC")

    for r in recommend(luong_mua, nhiet_do, do_am, muc):
        st.write("•", r)
